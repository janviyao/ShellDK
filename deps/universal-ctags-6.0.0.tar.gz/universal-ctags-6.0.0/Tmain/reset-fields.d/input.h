struct point { double x, y };
