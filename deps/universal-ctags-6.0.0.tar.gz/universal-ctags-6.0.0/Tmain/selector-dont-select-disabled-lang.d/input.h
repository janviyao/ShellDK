@interface Ctags
@end

struct s {
  int i;
};
