RSpec.describe "A" do
  describe "a" do
    it "hangs" do
      {
        for: nil
      }
      {
        for: nil
      }
    end
  end
end
