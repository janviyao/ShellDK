DEFINE(x, 1);
register(eax);
