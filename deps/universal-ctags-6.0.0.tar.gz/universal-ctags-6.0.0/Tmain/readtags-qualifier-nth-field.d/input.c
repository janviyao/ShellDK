/* ctags --options=NONE --sort=yes--kinds-C=+z --fields=+o --pseudo-tags=-TAG_PROGRAM_VERSION output.tags */
int z(int y, int x)
{
	return 0;
}
