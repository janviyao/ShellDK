class Foo:
    def doIt():
        pass
