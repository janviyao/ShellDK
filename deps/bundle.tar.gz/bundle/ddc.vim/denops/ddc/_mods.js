// NOTE: It is dummy module.  The file will be overwritten by
// "ddc#set_static_import_path()".
export const mods = {};
