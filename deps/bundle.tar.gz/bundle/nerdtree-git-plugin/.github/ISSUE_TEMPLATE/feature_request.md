---
name: "Feature Request"
about: "What new feature are you requesting for nerdtree-git-plugin?"
labels: "feature request"
---

#### Description

