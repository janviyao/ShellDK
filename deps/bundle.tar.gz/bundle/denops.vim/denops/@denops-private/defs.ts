// No body would leave Vim session for 7 days
export const responseTimeout = 1000 * 60 * 60 * 24 * 7;
