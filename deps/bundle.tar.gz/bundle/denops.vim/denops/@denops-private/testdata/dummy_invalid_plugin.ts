import type { Denops } from "https://deno.land/x/denops_core@v6.0.5/mod.ts";

export function main(_denops: Denops): Promise<void> {
  throw new Error("This is dummy error");
}
