export { test } from "./tester.ts";
export type { TestDefinition } from "./tester.ts";
