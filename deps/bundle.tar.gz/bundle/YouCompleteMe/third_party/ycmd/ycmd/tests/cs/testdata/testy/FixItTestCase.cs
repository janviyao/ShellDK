namespace testy {
    public class FixItTestCase {
        public FixItTestCase() {
            int li = 5;
            const int j = 5;
        }
    }
}
