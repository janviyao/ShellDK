require( [ 'coollib/cool_object' ], function ( cool_object ) {
  cool_object.
  cool_object.min
  cool_object.gn
} );

require( [ 'lamelib/lame_widget' ], function ( lame_widget ) {
  lame_widget.
  lame_widget.options.
} );

require( [ 'coollib/cool_widget' ], function ( cool_widget ) {
  cool_widget.options.
  cool_widget.
} );

require( 'no_such_lib/no_such_file', function( whatsit ) {
  whatsit.
  whatsit.ben
} );
