def f():
  pass

a = f()
b = f()
c = f()

str
