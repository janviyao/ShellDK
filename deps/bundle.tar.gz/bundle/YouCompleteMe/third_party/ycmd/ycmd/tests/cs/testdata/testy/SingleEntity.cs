using System;
using System.Data;

namespace testy
{
	class GotoTestCase
	{
	}
}
