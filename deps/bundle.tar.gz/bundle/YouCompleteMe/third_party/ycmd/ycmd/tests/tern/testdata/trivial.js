var X = {
  y: 'string',
  z: 'integer'
};
