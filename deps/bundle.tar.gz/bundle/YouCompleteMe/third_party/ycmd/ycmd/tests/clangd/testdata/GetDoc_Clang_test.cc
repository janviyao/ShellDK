#include "docstring.h"


/// docstring
void docstring_int_main_TU_file() {
  docstring_from_header_file();
  int x = 3;
}
