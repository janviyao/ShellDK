my_dict = dict()
my_dict

class MyClass():
    pass

my_instance = MyClass()
same_instance = my_instance
same_instance
