package com.puremourning.widget.core;

public class Utils
{
  public static int Test = 100;

  public static void DoSomething() {
    System.out.println( "test " + Test );
  }
}
