package com.puremourning.widget.input;

import com.puremourning.widget.core.Utils;

public class InputApp {
  public static void main( String[] args ) {
    Utils.DoSomething();
    if ( Utils.Test == 1 ) {

    }
  }
}
