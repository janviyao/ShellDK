
export class Bår {
  methodA(
    a: {
      foo: string;
      bar: number;
    }
  ) {}

  methød() {
    return '†est'.cha
  }

  å: number;
  åbc: number;
  abc: number;
  a: number;
}

var baz = new Bår(); baz.å;
baz.abc;
baz.a;
baz.å;

var føø_long_long = new Bår();
føø_long_long.methød();
føø_long_long.å;
føø_long_long.åbc;
føø_long_long.abc;


/**
 * Test unicøde st††††
 */
class Båøz
{

}
