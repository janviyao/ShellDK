void f(int b);
int main() { f(2); }
