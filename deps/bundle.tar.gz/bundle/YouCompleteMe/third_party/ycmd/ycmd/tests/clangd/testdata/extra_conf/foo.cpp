#include "foo.h"

int main() {
    Structure structure;
    structure.
}
