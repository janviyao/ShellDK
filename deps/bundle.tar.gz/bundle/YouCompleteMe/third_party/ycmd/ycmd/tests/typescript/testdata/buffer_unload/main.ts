import { Imported } from "./imported";
let imported = new Imported();
imported.
