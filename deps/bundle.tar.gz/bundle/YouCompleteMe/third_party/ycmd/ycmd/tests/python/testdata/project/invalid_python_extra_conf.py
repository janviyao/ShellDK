def Settings( **kwargs ):
  return {
    'interpreter_path': '/non/existing/python'
  }
