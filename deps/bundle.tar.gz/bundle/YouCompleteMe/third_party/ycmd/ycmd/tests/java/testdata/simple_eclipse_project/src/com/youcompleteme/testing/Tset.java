package com.youcompleteme.testing;

import java.util.Set;
import com.youcompleteme.*;

public class Tset {
  Set<Test> tset;

  public Set<Test> getTset() {
    return tset;
  }
}
