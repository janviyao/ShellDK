using System;

namespace testy
{
	public class ImportTest
	{
		public static void Main (string[] args)
		{
			new Date
		}
	}
}
