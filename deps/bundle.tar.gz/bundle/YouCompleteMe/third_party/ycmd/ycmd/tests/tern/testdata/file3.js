
function method( xyz ) {
    return global
}
