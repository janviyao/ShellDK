// this file is used in RunCompleterCommand_GoTo_Clang_ZeroBasedLineAndColumn_test
struct Foo {
  int x;
  int y;
  char c;
};

int main()
{
  Foo foo;
  return 0;
}
