class P:
  def from_base( self ): pass
  def c( self ): pass
