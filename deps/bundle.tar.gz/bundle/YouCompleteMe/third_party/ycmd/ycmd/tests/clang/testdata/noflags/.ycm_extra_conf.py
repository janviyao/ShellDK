def Settings( **kwargs ):
  return { 'flags': [] }
