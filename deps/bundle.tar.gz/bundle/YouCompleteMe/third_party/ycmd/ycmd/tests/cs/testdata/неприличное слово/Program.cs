using System;

namespace testy
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Console.
		}
	}
}
