
def CSharpSolutionFile( path, **kwargs ):
  return "nosuch.sln"

