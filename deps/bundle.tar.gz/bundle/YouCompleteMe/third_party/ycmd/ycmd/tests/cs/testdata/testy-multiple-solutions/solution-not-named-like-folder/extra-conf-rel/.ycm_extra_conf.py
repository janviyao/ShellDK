
def CSharpSolutionFile( path, **kwargs ):
  return "testy2.sln"

