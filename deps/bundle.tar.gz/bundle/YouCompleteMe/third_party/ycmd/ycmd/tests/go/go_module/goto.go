package main

func dummy() {

}

func main() {
    dummy() //GoTo
}

func foo() {
    diagnostics_test
}
