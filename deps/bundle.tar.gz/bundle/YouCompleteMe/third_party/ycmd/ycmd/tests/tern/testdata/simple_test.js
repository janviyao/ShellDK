var simple_test_obect = {
  'a_simple_function': function( param ) {
    return 'yes';
  },

  'basic_type': 100,

  'object': {
    'basic_type': 'test_string'
  }
};

var simple_assignment = simple_test_obect.
var query_assignment = simple_test_obect.typ
var query_assignment = simple_test_obect.asf

function blah( simple_test_obect ) {
    simple_test_obect.a_simple_function;
}

blah( simple_test_obect ); simple_test_obect = null;
