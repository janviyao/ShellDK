//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_TOOLBAR1			101
//#define ID_TB_BLOB			  40001
//#define ID_TB_CIRCLE			  40002

