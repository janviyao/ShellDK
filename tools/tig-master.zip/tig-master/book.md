# Summary

 - [Installation](INSTALL.adoc)
 - [Release notes](NEWS.adoc)
 - [tig(1)](doc/tig.1.adoc)
 - [tigrc(5)](doc/tigrc.5.adoc)
 - [Manual](doc/manual.adoc)
 - [Screenshots](https://www.flickr.com/photos/jonasfonseca/albums/72157614470764617)
 - Developer Documentation 
   - [Testing](test/README.adoc)
