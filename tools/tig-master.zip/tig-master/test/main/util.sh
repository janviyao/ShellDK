#!/bin/sh

# Set timestamp to return from gettimeofday-like stub.
export TEST_TIME_NOW=1401046937

# The default formatted date of the above timestamp.
YYY_MM_DD_HH_MM="2014-05-25 19:42"
