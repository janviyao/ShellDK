.. _guessing:

======================================================================
Choosing a proper parser in ctags
======================================================================

.. IN MAN PAGE

.. contents:: `Table of contents`
	:depth: 3
	:local:

See :ref:`ctags(1) <ctags(1)>`.
