*Tinst* installation test
---------------------------------------------------------------------

:Maintainer: Masatake YAMATO <yamato@redhat.com>

-----

tinst target is for testing the result of ``make install``.

::

   $ make tinst
