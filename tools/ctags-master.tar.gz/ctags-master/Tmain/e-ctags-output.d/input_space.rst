===================================
A spaces B
===================================
Ths should be recorded in e-ctags output.
