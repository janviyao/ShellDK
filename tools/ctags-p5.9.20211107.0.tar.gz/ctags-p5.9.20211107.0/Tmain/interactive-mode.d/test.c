#include <stdio.h>

void say_hello() {
  printf("hello world\n");
}

int main(int argc, char **argv) {
  say_hello();
}
