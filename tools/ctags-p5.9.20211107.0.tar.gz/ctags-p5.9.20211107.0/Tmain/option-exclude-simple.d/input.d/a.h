#ifndef A
#define A
struct A {
	int a0, a1;
};
#endif
