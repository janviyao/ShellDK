#define Z
namespace X {
  extern class Y {
    int m;
  } v;
}
#undef Z
